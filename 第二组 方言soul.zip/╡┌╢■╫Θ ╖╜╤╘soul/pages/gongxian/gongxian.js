Page({

  /**
   * 页面的初始数据
   */
  data: {
    mHidden: false,
    currentData: 0,
    cateItems: [
      {
        cate_id: 1,
        cate_name: "小明",
        cate_jifen: 1000,
      },
      {
        cate_id: 2,
        cate_name: "小红",
        cate_jifen: 999,
      },
      {
        cate_id: 3,
        cate_name: "小王",
        cate_jifen: 998,
      },
      {
        cate_id: 4,
        cate_name: "小钱",
        cate_jifen: 997,
      },
      {
        cate_id: 5,
        cate_name: "小张",
        cate_jifen: 996,
      },
    ],
    localItems:[
      {
        local_id: 1,
        local_name: "北京",
        local_jifen: 10000,
      },
      {
        local_id: 2,
        local_name: "上海",
        local_jifen: 9999,
      },
      {
        local_id: 3,
        local_name: "重庆",
        local_jifen: 9998,
      },
      {
        local_id: 4,
        local_name: "四川",
        local_jifen: 9997,
      },
      {
        local_id: 5,
        local_name: "东北",
        local_jifen: 9996,
      },
    ],
    curNav: 1,
    curIndex: 0
  },
  changeModal: function () {
    this.setData({
      mHidden: true
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },
  //获取当前滑块的index
  bindchange: function (e) {
    const that = this;
    that.setData({
      currentData: e.detail.current
    })
  },
  //点击切换，滑块index赋值
  checkCurrent: function (e) {
    const that = this;

    if (that.data.currentData === e.target.dataset.current) {
      return false;
    } else {

      that.setData({
        currentData: e.target.dataset.current
      })
    }
  }
})