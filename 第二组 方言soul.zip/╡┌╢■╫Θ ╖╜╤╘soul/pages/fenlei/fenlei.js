Page({
  data: {
    cateItems: [
      {
        cate_id: 1,
        cate_name: "官话方言",
        cate_jieshao:"官话方言是以北京话为基础定义的北方部分语言统称，即广义的北方话。官话方言内部一致性较强，它的分布地域最广，使用人口约占汉族总人口的73%。",
        ishaveChild: true,
        children:
          [
            {
              child_id: 1,
              name: '东北官话',
              image: "/images/cool.png"
            },
            {
              child_id: 2,
              name: '北京官话',
              image: "/images/cool.png"
            },
            {
              child_id: 3,
              name: '冀鲁官话',
              image: "/images/cool.png"
            },
            {
              child_id: 4,
              name: '辽胶官话',
              image: "/images/cool.png"
            },
            {
              child_id: 5,
              name: '中原官话',
              image: "/images/cool.png"
            },
            {
              child_id: 6,
              name: '兰银官话',
              image: "/images/cool.png"
            },
            {
              child_id: 7,
              name: '江淮官话',
              image: "/images/cool.png"
            },
            {
              child_id: 8,
              name: '西南官话',
              image: "/images/cool.png"
            }
          ]
      },
      {
        cate_id: 2,
        cate_name: "吴方言",
        cate_jieshao: "吴方言又称江东话、江南话、江浙话、吴越语。周朝至今有三千多年悠久历史，底蕴深厚。在中国分布于今浙江、江苏南部、上海、安徽南部、江西东北部、福建北一角，使用人口九千多万。",
        ishaveChild: true,
        children:
          [
            {
              child_id: 1,
              name: '太湖片',
              image: "/images/cool.png"
            },
            {
              child_id: 2,
              name: '台州片',
              image: "/images/cool.png"
            },
            {
              child_id: 3,
              name: '金衢片',
              image: "/images/cool.png"
            },
            {
              child_id: 4,
              name: '上丽片',
              image: "/images/cool.png"
            },
            {
              child_id: 5,
              name: '瓯江片',
              image: "/images/cool.png"
            },
            {
              child_id: 6,
              name: '宣州片',
              image: "/images/cool.png"
            },
          ]
      },
      {
        cate_id: 3,
        cate_name: "客家方言",
        cate_jieshao: "客语是汉语方言中除官话以外分布省区最多的方言，广泛地分布在广东、福建、江西、湖南、广西、海南、四川和台湾共8个省区。国内说客语的人口约5000万，占全国总人口的4%以上。",
        ishaveChild: true,
        children:
          [
            {
              child_id: 1,
              name: '粤台片',
              image: "/images/cool.png"
            },
            {
              child_id: 2,
              name: '粤北片',
              image: "/images/cool.png"
            },
            {
              child_id: 3,
              name: '海陆片',
              image: "/images/cool.png"
            },
            {
              child_id: 4,
              name: '粤西片',
              image: "/images/cool.png"
            },
            {
              child_id: 5,
              name: '汀州片',
              image: "/images/cool.png"
            },
            {
              child_id: 6,
              name: '于信片',
              image: "/images/cool.png"
            },
            {
              child_id: 7,
              name: '宁龙片',
              image: "/images/cool.png"
            },
            {
              child_id: 9,
              name: '铜桂片',
              image: "/images/cool.png"
            }
          ]
      },
      {
        cate_id: 4,
        cate_name: "闽方言",
        cate_jieshao: "闽方言主要是按地区进行划分的。闽语主要通行于福建、广东、台湾三省和浙江省南部以及江、广西、江苏三省（区）的个别地区。使用人口约4000万。",
        ishaveChild: true,
        children:
          [
            {
              child_id: 1,
              name: '闽南语',
              image: "/images/cool.png"
            },
            {
              child_id: 2,
              name: '闽东语',
              image: "/images/cool.png"
            },
            {
              child_id: 3,
              name: '闽北语',
              image: "/images/cool.png"
            },
            {
              child_id: 4,
              name: '闽中语',
              image: "/images/cool.png"
            },
            {
              child_id: 5,
              name: '莆仙语',
              image: "/images/cool.png"
            }
          ]
      },
      {
        cate_id: 5,
        cate_name: "粤方言",
        cate_jieshao: "粤语源自北方古汉语，与官话同属秦语支。粤语在中国岭南的广东、广西、海南、香港、澳门等处广泛流行，使用人口除官话外最大。",
        ishaveChild: true,
        children: 
          [
            {
              child_id: 1,
              name: '广府片',
              image: "/images/cool.png"
            },
            {
              child_id: 2,
              name: '莞宝片',
              image: "/images/cool.png"
            },
            {
              child_id: 3,
              name: '四邑片',
              image: "/images/cool.png"
            },
            {
              child_id: 4,
              name: '勾漏片',
              image: "/images/cool.png"
            },
            {
              child_id: 5,
              name: '罗广片',
              image: "/images/cool.png"
            },
            {
              child_id: 6,
              name: '高阳片',
              image: "/images/cool.png"
            },
            {
              child_id: 7,
              name: '邕浔片',
              image: "/images/cool.png"
            },
            {
              child_id: 8,
              name: '钦廉片',
              image: "/images/cool.png"
            }
          ]
      },
      {
        cate_id: 6,
        cate_name: "赣方言",
        cate_jieshao: "赣语为汉族江右民系使用的主要语言。使用人口多数在江西省境内，主要分布在赣江中下游、抚河流域及鄱阳湖流域以及周边、湘东和闽西北、皖西南、鄂东南和湘西南等地区。",
        ishaveChild: true,
        children:
         [
            {
              child_id: 1,
              name: '昌都片',
              image: "/images/cool.png"
            },
            {
              child_id: 2,
              name: '宜浏片',
              image: "/images/cool.png"
            },
            {
              child_id: 3,
              name: '吉茶片',
              image: "/images/cool.png"
            },
            {
              child_id: 4,
              name: '抚广片',
              image: "/images/cool.png"
            },
            {
              child_id: 5,
              name: '鹰弋片',
              image: "/images/cool.png"
            },
            {
              child_id: 6,
              name: '耒资片',
              image: "/images/cool.png"
            },
            {
              child_id: 7,
              name: '洞绥片',
              image: "/images/cool.png"
            },
            {
              child_id: 8,
              name: '大通片',
              image: "/images/cool.png"
            },
            {
              child_id: 9,
              name: '怀岳片',
              image: "/images/cool.png"
            }
         ]
      }
    ],
    curNav: 1,
    curIndex: 0
  },

  //事件处理函数  
  switchRightTab: function (e) {
    // 获取item项的id，和数组的下标值  
    let id = e.target.dataset.id,
      index = parseInt(e.target.dataset.index);
    // 把点击到的某一项，设为当前index  
    this.setData({
      curNav: id,
      curIndex: index
    })
  }
}) 