const recorderManager = wx.getRecorderManager()
const innerAudioContext = wx.createInnerAudioContext()
var util = require("../../utils/util.js")

var app = getApp()

//搜索查询函数
var searchRequest = (options) => {
  //getHttpHeader会把所有键名转为大写，所有者客户端取键名的时候一定要大写，最终SDK会给键名加上一个HTTP_的前缀
  var header = {};
  header['XYLISTSTART'] = options.data.searchliststart.toString();
  header['XYLISTNUM'] = options.data.listnum.toString();

  // 请求精选数据
  // 测试的请求地址，用于测试会话
  qcloud.request({
    // 要请求的地址
    url: options.data.voicesUrl,

    //自定义的头部信息
    header: header,
    data: {
      searchText: options.data.textSearch,
      searchArea: options.data.areaSearch,
      searchOrnot: options.data.activeIndex.toString()
    },
    method: 'POST',
    // 请求之前是否登陆，如果该项指定为 true，会在请求之前进行登录
    //login: true,

    success(result) {
      //showSuccess('请求成功完成');
      console.log('request success', result);
      var arr = result.data;

      // 获取当前现有数据进行保存
      var list = options.data.searchlist;
      var datanum = 0;
      for (var key in arr) {
        //key是属性,object[key]是值
        list.push(arr[key]);//往数组中放属性
        datanum++;
      }

      // 重新写入数据
      options.setData({
        searchlist: list,
        returnedDataNum: datanum
      });
    },

    fail(error) {
      //showModel('请求失败', error);
      console.log('request fail', error);
    },

    complete() {
      console.log('request complete');
    }
  })
};

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentData: 0,
    focus: false,
    endSpeak: false,
    searchlist: [],
    searchliststart: 0,
    listnum: 10,  //一次取多少数目
    textType: 'default',
    searchValue: '',
    textSearch: '',
    areaSearch: '',
    searchTaped: 0,
    returnedDataNum: 0,
    chooseOver: true,
    kuHidden: true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  /**
   * 跳转搜索页面
   */
  suo: function() {
    wx.navigateTo({
      url: '../search/search',
    })
  },
  goku: function () {
    wx.navigateTo({
      url: '../ku/ku',
    })
  },
  bindButtonTap: function () {
    this.setData({
      focus: true
    })
  },  
  /**
   * 获取当前滑块的index
   */
  bindchange: function (e) {
    const that = this;
    that.setData({
      currentData: e.detail.current
    })
  },
  //点击切换，滑块index赋值
  checkCurrent: function (e) {
    const that = this;

    if (that.data.currentData === e.target.dataset.current) {
      return false;
    } else {

      that.setData({
        currentData: e.target.dataset.current
      })
    }
  },
  /*
  语音资料选择
  */ 
  selectDistrict: function () {
    wx.navigateTo({
      url: '../placepicker/placepicker',
    })
  },
  selectTextcat: function () {
    wx.navigateTo({
      url: '../textcat/textcat',
    })
  },
  /**
   * 开始录音
   */
  start: function () {
    const options = {
      duration: 10000,//指定录音的时长，单位 ms
      sampleRate: 16000,//采样率
      numberOfChannels: 1,//录音通道数
      encodeBitRate: 96000,//编码码率
      format: 'mp3',//音频格式，有效值 aac/mp3
      frameSize: 50,//指定帧大小，单位 KB
    }
    //开始录音
    recorderManager.start(options);
    recorderManager.onStart(() => {
      console.log('recorder start')
    });
    //错误回调
    recorderManager.onError((res) => {
      console.log(res);
    })
  },
  /**
   * 停止录音
   */
  stop: function () {
    recorderManager.stop();
    recorderManager.onStop((res) => {
      // this.tempFilePath = res.tempFilePath;
      // console.log('停止录音', res.tempFilePath)
      // const { tempFilePath } = res
      var tempFilePath = res.tempFilePath
      var endTime = util.formatTime(new Date())
      console.log("tempFilePath: " + tempFilePath)
      console.log("endTime: " + endTime)
      wx.saveFile({
        tempFilePath: tempFilePath,
        success: function (res) {
          //持久路径  
          //本地文件存储的大小限制为 100M  
          var savedFilePath = res.savedFilePath
          var arr = endTime.split(' ');
          app.savedFilePath = savedFilePath
          console.log("savedFilePath: " + savedFilePath)
          wx.cloud.uploadFile({
            cloudPath: app.globalData.names[0] + '/' + 
              app.globalData.userInfo.nickName + '/' +
              arr[1],
            filePath: app.savedFilePath,
            success: res => {
              console.log("上传成功")
              console.log(res.fileID)
            },
            fail: e => {
              console.log("上传失败")
            }
          })
        }
      })
    })
    this.setData({
      endSpeak: true,
      kuHidden: false
    })
  },
  /**
   * 播放录音
   */
  play: function () {
    innerAudioContext.autoplay = true
    innerAudioContext.src = app.savedFilePath,
      innerAudioContext.onPlay(() => {
        console.log('开始播放')
      })
    innerAudioContext.onError((res) => {
      console.log(res.errMsg)
      console.log(res.errCode)
    })
    this.setData({
      endSpeak: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      chooseOver: app.globalData.chooseOver
    })
  },
  
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },
  
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },

  wxVoiceTap: function (e) {
    var temData = e.target.dataset.key;
    //console.log('id', e.target.dataset.index);
    //console.log('e.target.dataset', e.target.dataset);
    try {
      if (this.data.activeIndex == 0) {
        wx.setStorageSync('ArrayForVoice', this.data.voiceslist)
      }
      else if (this.data.activeIndex == 2) {
        wx.setStorageSync('ArrayForVoice', this.data.searchlist)
      }
      wx.setStorageSync('IndexForVoice', e.target.dataset.index);
      wx.setStorageSync('TextForVoice', temData);
    } catch (e) {
      console.log('langMaterial Type set error:', temData)
    }
    wx.navigateTo({
      url: '../xyvoice/xyvoice',
    })
    //console.log('navigateTo:', 'xyrecorder')
  },

  bindSearch: function () {
    //setTimeout(function () {
    //}, 1000);
    var that = this;
    that.setData({
      searchlist: [],
      searchliststart: 0,
      returnedDataNum: 0,
      searchTaped: 1
    });
    if (that.data.textSearch == '' && that.data.areaSearch == '') {
      wx.showToast({
        title: '请输入查询内容',
      })
    } else {
      searchRequest(that);
      setTimeout(function () {
        if (that.data.returnedDataNum == 0) {
          wx.showToast({
            title: '还没数据呢，您来录一段吧！',
          })
        }
      }, 1000);

    }
  },

  bindTextInput: function (e) {
    console.log('bindTextInput', e.detail.value);
    this.setData({
      textSearch: e.detail.value
    })
  },

  bindAreaInput: function (e) {
    this.setData({
      areaSearch: e.detail.value
    })
  },
})